I assumed that both todoList and todoManager should be accessible to the todo app.
I assumed for isWithinMonthYear, that both month and year must match.
